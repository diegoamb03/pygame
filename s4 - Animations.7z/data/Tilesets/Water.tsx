<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Water" tilewidth="64" tileheight="64" tilecount="1" columns="1">
 <image source="../../graphics/environment/Water.png" width="64" height="64"/>
</tileset>
